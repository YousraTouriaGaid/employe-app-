package com.example.crudemployer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudEmployerApplicationTests {

    @Test
    void contextLoads() {
    }

}
